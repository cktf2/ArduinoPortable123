# mlx90640-library ![Build Status](https://github.com/adafruit/Adafruit_MLX90640/workflows/Arduino%20Library%20CI/badge.svg)

MLX90640 library functions
