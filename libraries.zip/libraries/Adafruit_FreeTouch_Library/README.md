# Adafruit_FreeTouch [![Build Status](https://github.com/adafruit/Adafruit_FreeTouch/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_FreeTouch/actions)

A QTouch-compatible library
